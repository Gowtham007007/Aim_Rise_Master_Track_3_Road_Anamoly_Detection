import os,sys,cv2,time,torch
import numpy as np
import tensorflow as tf
from pathlib import Path
from tkinter import Tk,Label
from PIL import Image,ImageTk

FILE = Path(__file__).resolve()
ROOT = FILE.parents[0]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from utils.general import scale_boxes,non_max_suppression,xywh2xyxy
from utils.augmentations import letterbox
from ultralytics.utils.plotting import Annotator,colors

base_path=os.path.expanduser("~/pothole_project")

class_names=[
"longitudinal_crack","transverse_crack","alligator_crack",
"pothole","repair","other","barrier","cone"
]

INPUT_SIZE=320
TRACK_RESET=5
tracked_centers=set()
last_track_reset=time.time()

interpreter=tf.lite.Interpreter(model_path=os.path.join(base_path,"best-fp16.tflite"))
interpreter.allocate_tensors()
input_details=interpreter.get_input_details()
output_details=interpreter.get_output_details()

cap=cv2.VideoCapture(os.path.join(base_path,"road6.mp4"))

root=Tk()
root.attributes("-fullscreen",True)
video_label=Label(root)
video_label.pack(fill="both",expand=True)

def update_frame():
    global tracked_centers,last_track_reset

    ret,frame=cap.read()
    if not ret:
        cap.set(cv2.CAP_PROP_POS_FRAMES,0)
        ret,frame=cap.read()

    img,ratio,pad=letterbox(frame,(INPUT_SIZE,INPUT_SIZE),auto=False)

    rgb=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    rgb=np.expand_dims(rgb,0).astype(np.float32)/255.0

    interpreter.set_tensor(input_details[0]['index'],rgb)
    interpreter.invoke()
    pred=interpreter.get_tensor(output_details[0]['index'])

    pred=torch.from_numpy(pred)
    if pred.shape[1]<pred.shape[2]:
        pred=pred.transpose(1,2)

    pred[...,0:4]=xywh2xyxy(pred[...,0:4])
    pred[...,0:4]*=INPUT_SIZE

    det=non_max_suppression(pred,0.25,0.45)[0]

    annotator=Annotator(frame.copy(),line_width=2)

    if len(det):
        det[:,:4]=scale_boxes(img.shape[:2],det[:,:4],frame.shape).round()

        for *xyxy,conf,cls in reversed(det):
            cx=int((xyxy[0]+xyxy[2])/2)
            cy=int((xyxy[1]+xyxy[3])/2)

            duplicate=False
            for px,py in tracked_centers:
                if abs(cx-px)<60 and abs(cy-py)<60:
                    duplicate=True
                    break

            if not duplicate:
                tracked_centers.add((cx,cy))
                c=int(cls)
                annotator.box_label(xyxy,f"{class_names[c]} {conf:.2f}",color=colors(c,True))

    # reset tracker every few seconds
    if time.time()-last_track_reset>TRACK_RESET:
        tracked_centers=set()
        last_track_reset=time.time()

    display=annotator.result()
    w=root.winfo_width()
    h=root.winfo_height()
    if w>1 and h>1:
        display=cv2.resize(display,(w,h))

    display=cv2.cvtColor(display,cv2.COLOR_BGR2RGB)
    imgtk=ImageTk.PhotoImage(Image.fromarray(display))
    video_label.imgtk=imgtk
    video_label.configure(image=imgtk)

    root.after(1,update_frame)

update_frame()
root.mainloop()
